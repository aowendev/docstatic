#!/usr/bin/env bash
set -euo pipefail

# Load Nix environment if present
if [ -f "/home/toolbox/.nix-profile/etc/profile.d/nix.sh" ]; then
  . "/home/toolbox/.nix-profile/etc/profile.d/nix.sh"
fi

activate_toolset() {
  local name="$1"
  local profile="/home/toolbox/profiles/$name"
  if [ -e "$profile" ]; then
    export PATH="$profile/bin:$PATH"
    export MANPATH="$profile/share/man:${MANPATH:-}"
  else
    echo "Unknown toolset: $name" >&2
    exit 2
  fi
}

# TOOLSET is comma-separated e.g. base,node
IFS=',' read -ra SETS <<< "${TOOLSET:-base}"
for s in "${SETS[@]}"; do
  activate_toolset "$s"
done

echo "Toolbox ready. Enabled toolsets: ${TOOLSET:-base}"
exec bash
