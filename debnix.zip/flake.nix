{
  description = "Toolbox MVP: two toolsets with runtime selection";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-24.11";
    flake-utils.url = "github:numtide/flake-utils";
  };

  outputs = { self, nixpkgs, flake-utils }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs { inherit system; };

        mkToolset = name: packages:
          pkgs.buildEnv {
            inherit name;
            paths = packages;
          };
      in
      {
        packages = {
          # Toolset 1: base utilities
          toolset-base = mkToolset "toolset-base" (with pkgs; [
            bashInteractive
            git
            curl
            cacert
            coreutils
          ]);

          # Toolset 2: Node runtime
          toolset-node = mkToolset "toolset-node" (with pkgs; [
            nodejs_20
          ]);
        };
      });
}

